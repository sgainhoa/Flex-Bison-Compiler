
Base para implementar el traductor de la práctica de compilación

Programa principal y make:

  Makefile
  main.cpp

Fciheros flex y bison:

  tokens.l
  parser.y

Funciones y objetos auxiliares:

  Codigo.cpp
  Codigo.hpp

Ficheros de prueba:

  prueba1.in
  prueba2.in
  prueba3.in
  prueba4.in
